package com.bms.account.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bms.account.entity.Customer;
import com.bms.account.repo.CustomerRepository;
import com.bms.account.service.CustomerRegistrationService;
import reactor.core.publisher.Mono;

@Service
public class CustomerRegistrationServiceImpl implements CustomerRegistrationService {

	@Autowired
	private CustomerRepository customerRepository;


	@Override
	public Mono<Customer> registerCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Mono<Customer> viewCustomer(Customer customer) {
		return customerRepository.findByUsernameAndPassword(customer.getUsername(), customer.getPassword());
	}

}
